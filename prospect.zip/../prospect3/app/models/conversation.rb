class Conversation < ApplicationRecord
  belongs_to :prospect
end
